<?php
	
	$count = 29;
	
	do{
	    $count++;
	    echo "Count " . $count . "\n";
	}
	while($count <= 30);

?>