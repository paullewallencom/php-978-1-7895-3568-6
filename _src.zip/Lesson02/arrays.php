<?php

    $myinfo = array("John", 25, "USA", "College");
     
    echo "My name is ". $myinfo[0] . ".\n";
    echo "I am " . $myinfo[1] . " years old. \n";
    echo "I live in " . $myinfo[2] . ".\n";
    echo "My latest education level is " . $myinfo[3] .".\n";
?>


