<?php
	
	$count = 29;

	while($count <= 30){
		$count++;
		echo "Count " . $count . "\n";
	}

?>