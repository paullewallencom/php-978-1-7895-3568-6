<?php

    $name = "John Doe";
    $age = 25;
    $hourlyRate = 10.50;
    $hours = 40;

    echo $name . " is " . $age . " years old.<br>\n";
    echo $name . " makes $" . $hourlyRate . " an hour.<br> \n";
    echo $name . " worked " . $hours . " this week.\n";


?>