<?php

    $animal = "cow";

    if($animal == "cat"){
        echo "meow\n";
    }
    else if ($animal == "dog"){
        echo "woof\n";
    }
    else if($animal == "lion"){
        echo "roar\n";
    }
    else if ($animal == "cow"){
        echo "moo\n";
    }
    else {
        echo "What does the fox say?\n";
    }

?>