<?php

	$hourlyRate = 10.00;
	$hoursWorked = 12;
	$rateMultiplier = 1.5;
	$commissionRate = 0.10;
	$grossSales = 2500.00;
	$bonus = 0;


	$holidayRate = $hourlyRate * $rateMultiplier;
	$holidayPay = $holidayRate * $hoursWorked;
	$commission = $commissionRate * $grossSales;

	if($grossSales >= 1000){
		$bonus = 1000;
     }

	$salary = $holidayPay + $commission;

	echo "Salary       $" . $salary . "<br>";
	echo "Commission   $" . $commission . "<br>";
	echo "Bonus      + $" . $bonus . "<br>";
	echo "-------------------------------<br>";
	echo "Total  $" . ($salary + $commission + $bonus) . "<br>";

?>