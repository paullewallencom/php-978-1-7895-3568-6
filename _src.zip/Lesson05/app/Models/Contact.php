<?php
namespace App\Models;

class Contact
{
    public function getContacts()
    {
        //return an array of contacts
        return ['joe', 'bob', 'kerry', 'dave'];
    }
}
